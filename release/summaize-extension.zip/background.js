(()=>{chrome.runtime.onMessage.addListener((a,i,n)=>{if(a.type==="SUMMARIZE_PAGE")return l(a.payload).then(n).catch(r=>{let t={error:r.message};r.cause instanceof Error?t.cause=r.cause.message:r.cause&&(t.cause=String(r.cause)),n(t)}),!0});async function l(a){let{title:i,text:n,url:r}=a,t=`summary_${r}`;try{let e=await chrome.storage.local.get([t]);if(e&&e[t])return e[t]}catch(e){console.warn("Cache Retrieval Error:",e)}let c="AIzaSyDegknUGXCgPRXUzfuOtjxGbtU4w0UnvKI";if(!c)throw new Error("Gemini API Key is not configured.");let g=`
    You are an expert content summarizer. Summarize the following web page content.
    
    Page Title: ${i}
    
    Content:
    ${n.substring(0,25e3)}
    
    Please provide the response in the following JSON format:
    {
      "bulletPoints": ["point 1", "point 2", ...],
      "keyInsights": ["insight 1", "insight 2", ...],
      "readingTime": "X minutes"
    }
    
    Return ONLY the JSON. No markdown formatting.
  `;try{let e=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemma-3-27b-it:generateContent?key=${c}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:g}]}]})});if(!e.ok){let o=await e.text();throw new Error(`API Error: ${e.status}`,{cause:o})}let s=(await e.json()).candidates?.[0]?.content?.parts?.[0]?.text;if(!s)throw new Error("Empty response from AI.");let m=s.match(/\{[\s\S]*\}/);if(!m)throw new Error("Failed to parse AI response as JSON.",{cause:s});let u=JSON.parse(m[0]);try{await chrome.storage.local.set({[t]:u})}catch(o){console.warn("Cache Storage Error:",o)}return u}catch(e){throw console.error("Gemini API Error:",e),new Error("The AI failed to generate a summary.",{cause:e instanceof Error?e:new Error(String(e))})}}})();
